#!/bin/bash

../bin/milvus_server -c ../conf/server_config.yaml

