alter table Tables drop column owner_table;
alter table Tables drop column partition_tag;
alter table Tables drop column version;
